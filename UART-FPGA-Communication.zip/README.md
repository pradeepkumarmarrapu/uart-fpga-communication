
# UART Communication on Edge Artix-7 FPGA

This project demonstrates how to implement UART communication between two Edge Artix-7 FPGA boards using Verilog.

## Files

- `uart_tx.v`: UART transmitter module (TX side)
- `uart_rx.v`: UART receiver module (RX side)

## Description

- The TX board sends 8-bit data from switches whenever the value changes.
- The RX board receives the data via UART and outputs it on 8 LEDs.
- Both boards use a 100 MHz clock with a 9600 baud rate for UART communication.

## Hardware

- 2 x Edge Artix-7 FPGA boards
- Jumper wires (TX→RX and GND↔GND)

## License

This project is open-source under the MIT License.
